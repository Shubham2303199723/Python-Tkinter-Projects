from tkinter import *
import random
import pyperclip
length = None
password = None
password_generated = None
spam = None
def gen_pass():
    lower = "abcdefghijklmnopqrstuvwxyz"
    upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    numbers = "0123456789"
    sysmbols = "!@#$%^&*()_-+=?><["

    all_chars = lower + upper + numbers + sysmbols
    length = int(password_length_entry.get())
    global password, password_generated
    password = ''.join(random.sample(all_chars, length))
    password_generated.set(str(password))
    print("Generated Password ", password)

def copy_pass():
    global spam
    pyperclip.copy(password)
    spam = pyperclip.paste()

main = Tk()

main.title("Password Generator")
main.geometry("410x280")
main.resizable(False, False)
main.configure(bg="#272829")

password_generated = StringVar()

password_length_label = Label(text="Enter Length Value",bg="#272829", fg="#E5E5CB", font="Helvetica 12 bold")
password_length_label.place(x=15, y=30)

password_length_entry = Entry(width=30, bg="#E5E5CB")
password_length_entry.place(x=180, y=30)

generate_button = Button(text="Generate Password", bg="#E5E5CB",font="Helvetica 8 bold", width=18, command=gen_pass)
generate_button.place(x=180, y=80)

password_generated_label = Label(textvariable=password_generated, bg="#272829", fg="#E5E5CB", font="Helvetica 12 bold")
password_generated_label.place(x=80, y=130)

copy_password = Button(text="Copy Password", bg="#E5E5CB",font="Helvetica 8 bold", width=18, command=copy_pass)
copy_password.place(x=80, y=170)


main.mainloop()


