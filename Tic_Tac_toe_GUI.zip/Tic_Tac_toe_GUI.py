from tkinter import *
from tkinter import messagebox

def main_game():
    n = 0
    box_1_value = box_1.get().upper()
    box_2_value = box_2.get().upper()
    box_3_value = box_3.get().upper()
    box_4_value = box_4.get().upper()
    box_5_value = box_5.get().upper()
    box_6_value = box_6.get().upper()
    box_7_value = box_7.get().upper()
    box_8_value = box_8.get().upper()
    box_9_value = box_9.get().upper()

    check_box = [box_1_value, box_2_value, box_3_value,
                 box_4_value, box_5_value, box_6_value,
                 box_7_value, box_8_value, box_9_value
                ]
    
    for check in check_box:
        if check == "X":
            n = n+1
        elif check == "O":
            n = n+1
    if n == 9:
        if box_1_value == box_2_value == box_3_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_1_value == box_4_value == box_7_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_1_value == box_5_value == box_9_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_1_value == box_2_value == box_3_value == "O":
            messagebox.showinfo(" ", "O Won")
        elif box_1_value == box_4_value == box_7_value == "O":
            messagebox.showinfo(" ", "O Won")
        elif box_1_value == box_5_value == box_9_value == "O":
            messagebox.showinfo(" ", "O Won")
        elif box_2_value == box_5_value == box_8_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_2_value == box_5_value == box_8_value == "O":
            messagebox.showinfo(" ", "O Won")
        elif box_3_value == box_6_value == box_9_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_3_value == box_5_value == box_7_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_3_value == box_6_value == box_9_value == "O":
            messagebox.showinfo(" ", "O Won")
        elif box_3_value == box_5_value == box_7_value == "O":
            messagebox.showinfo(" ", "O Won")
        elif box_4_value == box_5_value == box_6_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_4_value == box_5_value == box_6_value == "O":
            messagebox.showinfo(" ", "O Won")
        elif box_7_value == box_8_value == box_9_value == "X":
            messagebox.showinfo(" ", "X Won")
        elif box_7_value == box_8_value == box_9_value == "O":
            messagebox.showinfo(" ", "O Won")
        else:
            messagebox.showinfo(" ", "Match Draw")
    else:
        messagebox.showinfo(" ", "Please Write Between X and O ")

def clear_entry():
    box_1.delete(0, END)
    box_2.delete(0, END)
    box_3.delete(0, END)
    box_4.delete(0, END)
    box_5.delete(0, END)
    box_6.delete(0, END)
    box_7.delete(0, END)
    box_8.delete(0, END)
    box_9.delete(0, END)

main = Tk()

main.geometry("390x400")
main.title("Tic Tac Toe")
main.configure(bg="#272727")

Heading_label = Label(text="TIC TAC TOE", font=("Arial", 20, "bold"), bg="#272727", fg="White")
Heading_label.place(x=100, y=30)

box_1 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_1.place(x=50, y=90, height=50)

box_2 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_2.place(x=150, y=90, height=50)

box_3 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_3.place(x=250, y=90, height=50)

box_4 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_4.place(x=50, y=180, height=50)

box_5 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_5.place(x=150, y=180, height=50)

box_6 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_6.place(x=250, y=180, height=50)

box_7 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_7.place(x=50, y=270, height=50)

box_8 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_8.place(x=150, y=270, height=50)

box_9 = Entry(width=5, font=("Arial", 15, "bold"), justify="center", bg="#b6b6b6")
box_9.place(x=250, y=270, height=50)

exit_button = Button(text="Exit", font=("Arial", 16, "bold"), command=main.quit)
exit_button.place(x=50, y=350, height=33)

clear_button = Button(text="Clear", font=("Arial", 16, "bold"), command=clear_entry)
clear_button.place(x=135, y=350, height=33)

enter_button = Button(text="Enter", font=("Arial", 16, "bold"), command=main_game)
enter_button.place(x=240, y=350, height=33)

main.mainloop()