from tkinter import *


def insert_task():
    main_data = (data_entry.get())
    msg_box.insert("end", main_data)
    data_entry.delete(0, END)

def delete_task():
    selected_task = msg_box.curselection()
    msg_box.delete(selected_task)

def exit_main():
    main.quit()


main = Tk()

main.geometry("500x480")
main.title("Todo Application")
main.resizable(True, True)
main.configure(bg="#182c25")

head_label = Label(text="Your All Todo's", font=("Arial", 16, "bold"), fg="white", bg="#182c25" )
head_label.place(x=100, y=20)

msg_box = Listbox(width=50, height=15)
msg_box.place(x=100, y=60)

data_entry = Entry(width=50)
data_entry.place(x=100, y=320, height=35)

add_button = Button(text="Add Task", width=9, font=("Arial", 10, "bold"), fg="Black", command=insert_task)
add_button.place(x=100, y=400)

delete_button = Button(text="Delete Task", width=11, font=("Arial", 10, "bold"), fg="Black", command=delete_task)
delete_button.place(x=200, y=400)

exit_button = Button(text="Exit", width=9, font=("Arial", 10, "bold"), fg="Black", command=exit_main)
exit_button.place(x=320, y=400)


main.mainloop()