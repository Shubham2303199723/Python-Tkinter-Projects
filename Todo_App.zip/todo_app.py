from tkinter import *
from tkinter import messagebox

def insert_task():
    main_data = (data_entry.get())
    if main_data:
        msg_box.insert("end", main_data)
        data_entry.delete(0, END)
    else:
        messagebox.showwarning("Warning", "Please Enter Task")

def delete_task():
    global selected_task
    selected_task = msg_box.curselection()
    if selected_task:
        msg_box.delete(selected_task)
    else:
        messagebox.showwarning("Warning", "Please Select Anyone" )

def update_task():
    select_task = msg_box.curselection()
    if select_task:
        for item in select_task:
            new_value = data_entry.get()
            if new_value:
                msg_box.delete(item)
                msg_box.insert("end", new_value)
                data_entry.delete(0, END)
            else:
                messagebox.showwarning("Warning", "Please Enter Task")
    else:
        messagebox.showwarning("Warning", "Please Select Anyone")

main = Tk()

main.geometry("500x480")
main.title("Todo Application")
main.resizable(False, False)
main.configure(bg="#182c25")

head_label = Label(text="Your All Todo's", font=("Arial", 16, "bold"), fg="white", bg="#182c25" )
head_label.place(x=100, y=20)

msg_box = Listbox(width=50, height=15)
msg_box.place(x=100, y=60)

data_entry = Entry(width=50)
data_entry.place(x=100, y=320, height=35)

add_button = Button(text="Add Task", width=9, font=("Arial", 10, "bold"), fg="Black", command=insert_task)
add_button.place(x=100, y=370)

delete_button = Button(text="Delete Task", width=11, font=("Arial", 10, "bold"), fg="Black", command=delete_task)
delete_button.place(x=198, y=370)

update_button = Button(text="Update Task", width=11, font=("Arial", 10, "bold"), fg="Black", command=update_task)
update_button.place(x=310, y=370)

exit_button = Button(text="Exit", width=11, font=("Arial", 10, "bold"), fg="Black", command=main.quit)
exit_button.place(x=200, y=420)

main.mainloop()