import tkinter as tk
from tkinter import *
from tkinter import ttk

total = None
number_1 = None
number_2 = None

def get_entry_value(value):
    global total
    global number_1
    global number_2
    if value == "+":
        number_1 = int(input_number_1.get())
        number_2 = int(input_number_2.get())
        total.set(str(number_1 + number_2))
    elif value == "-":
        number_1 = int(input_number_1.get())
        number_2 = int(input_number_2.get())
        total.set(str(number_1 - number_2))
    elif value == "*":
        number_1 = int(input_number_1.get())
        number_2 = int(input_number_2.get())
        total.set(str(number_1 * number_2))
    else:
        if int(input_number_1.get()) == 0:
            total.set(str("Number should not be 0"))
        if int(input_number_2.get()) == 0:
            total.set(str("Number should not be 0"))
        else:
            number_1 = int(input_number_1.get())
            number_2 = int(input_number_2.get())
            total.set(str(number_1 / number_2))

main = Tk()

main.title("Calculator")
main.geometry("310x280")
main.resizable(False, False)
main.configure(bg="#1A120B")

total = StringVar()

number_label_1 = Label(text="Number 1",bg="#1A120B", fg="#E5E5CB", font="Helvetica 12 bold")
number_label_1.place(x=15, y=30)

input_number_1 = Entry(width=30, bg="#E5E5CB")
input_number_1.place(x=105, y=30)

number_label_2 = Label(text="Number 2", bg="#1A120B", fg="#E5E5CB", font="Helvetica 12 bold")
number_label_2.place(x=15, y=80)

input_number_2 = Entry(width=30, bg="#E5E5CB")
input_number_2.place(x=105, y=80)

number_label_total = Label(textvariable=total, bg="#1A120B", fg="#E5E5CB", font="Helvetica 12 bold")
number_label_total.place(x=100, y=220)

plus_button = Button(text="+", bg="#E5E5CB",font="Helvetica 8 bold", width=4, command=lambda:get_entry_value("+"))
plus_button.place(x=105, y=125)

minus_button = Button(text="-", bg="#E5E5CB",font="Helvetica 8 bold", width=4, command=lambda:get_entry_value("-"))
minus_button.place(x=155, y=125)

multi_button = Button(text="*", bg="#E5E5CB",font="Helvetica 8 bold", width=4,command=lambda:get_entry_value("*"))
multi_button.place(x=205, y=125)

divide_button = Button(text="/", bg="#E5E5CB",font="Helvetica 8 bold", width=4,command=lambda:get_entry_value("/"))
divide_button.place(x=255, y=125)

quit_button = Button(text="Exit", bg="#E5E5CB", width=10, command=main.quit)
quit_button.place(x=150, y=170)

main.mainloop()